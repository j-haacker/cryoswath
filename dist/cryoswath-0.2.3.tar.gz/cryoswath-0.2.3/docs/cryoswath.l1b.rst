cryoswath.l1b module
====================

.. automodule:: cryoswath.l1b
   :members:
   :undoc-members:
   :show-inheritance:
