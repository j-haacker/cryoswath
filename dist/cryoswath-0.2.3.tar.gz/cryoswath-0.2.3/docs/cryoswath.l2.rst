cryoswath.l2 module
===================

.. automodule:: cryoswath.l2
   :members:
   :undoc-members:
   :show-inheritance:
